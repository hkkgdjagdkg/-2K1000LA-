#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <QComboBox>
#include <QList>
#include <QTimer>
#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QTextStream>


#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#define LED_GPIO_EXPORT           "/sys/class/gpio/export"
#define LED_GPIO_PIN            "49"
#define LED_GPIO_DIR          "/sys/class/gpio/gpio49/direction"
#define LED_GPIO_DIR_VAL          "out"
#define LED_GPIO_VALUE          "/sys/class/gpio/gpio49/value"

#define M0_GPIO_EXPORT           "/sys/class/gpio/export"
#define M0_GPIO_PIN            "51"
#define M0_GPIO_DIR          "/sys/class/gpio/gpio51/direction"
#define M0_GPIO_DIR_VAL          "out"
#define M0_GPIO_VALUE          "/sys/class/gpio/gpio51/value"

#define M1_GPIO_EXPORT           "/sys/class/gpio/export"
#define M1_GPIO_PIN            "50"
#define M1_GPIO_DIR          "/sys/class/gpio/gpio50/direction"
#define M1_GPIO_DIR_VAL           "out"
#define M1_GPIO_VALUE          "/sys/class/gpio/gpio50/value"

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    QString    ba_to_hex_str(QByteArray ba);
    QByteArray hex_str_to_ba(QString str);

    void init_gpio();
    void led_set(int state);
    void init_lora();
    void lora_set(int mode);

    enum{
        WOR = 0,
        NOR,
        CFG,
        SLP
    };

    uint8_t index = 1;  //当前操作的节点的索引
    bool received = true;
    uint16_t val_light,  val_co2, val_yw, val_bat;
    float val_temp, val_humi;
    uint32_t val_press;

public slots:
    void serial_refresh();
    void serial_init();
    void serial_write(QByteArray ba);
    void serial_read();
    void serial_read_timeout();
    void acq_timeout();
    void data_acq(uint8_t index);

private slots:

signals:
    void sgl_acq(uint8_t index);

private:
    Ui::Widget *ui;
    QSerialPort *serial;
    QTimer *serial_timer, *time_acp;
    QFile *file;
    int m_time = 600;
    QList<QPointF> m_ywList;

    int humi_min=0;
    int humi_max=10;
    bool humi_warning=false;
};
#endif // WIDGET_H
