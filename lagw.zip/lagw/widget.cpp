#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    init_gpio();

    //serial_refresh();
    serial_init();

    init_lora();

    file = new QFile;

    QDateTime dateTime= QDateTime::currentDateTime();//获取系统当前的时间
    QString str = dateTime .toString("yyyy-MM-dd-hh:mm:ss");//格式化时间

    file->setFileName(QApplication::applicationDirPath() + "/" + str +".txt");
    if(file->open(QIODevice::ReadWrite|QIODevice::Text)){

        qDebug()<<" create a new file ok";
    }else{
        qDebug()<<"failed to create a new file!";
    }



    //timer for acq timeout
    time_acp = new QTimer;
    connect(time_acp,SIGNAL(timeout()),this,SLOT(acq_timeout()));
    //acq
    connect(this,SIGNAL(sgl_acq(uint8_t)),this,SLOT(data_acq(uint8_t)));
    emit sgl_acq(index);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::init_gpio()
{
    int fd;
    //led
    fd = open(LED_GPIO_EXPORT,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,LED_GPIO_PIN,sizeof(LED_GPIO_PIN));
    ::close(fd);

    fd = open(LED_GPIO_DIR,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,LED_GPIO_DIR_VAL,sizeof(LED_GPIO_DIR_VAL));
    ::close(fd);
    //m0
    fd = open(M0_GPIO_EXPORT,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,M0_GPIO_PIN,sizeof(M0_GPIO_PIN));
    ::close(fd);

    fd = open(M0_GPIO_DIR,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,M0_GPIO_DIR_VAL,sizeof(M0_GPIO_DIR_VAL));
    ::close(fd);
    //m1
    fd = open(M1_GPIO_EXPORT,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,M1_GPIO_PIN,sizeof(M1_GPIO_PIN));
    ::close(fd);

    fd = open(M1_GPIO_DIR,O_WRONLY);
    if(fd == -1)
    {
        ;
    }
    write(fd,M1_GPIO_DIR_VAL,sizeof(M1_GPIO_DIR_VAL));
    ::close(fd);
}

void Widget::init_lora()
{

    lora_set(NOR);
    led_set(0);
}

void Widget::led_set(int state)
{
    int fd;

    fd = open(LED_GPIO_VALUE,O_WRONLY);
    if(fd > 0)
    {
        if(state == 1)
        {
            write(fd,"0",1);
        }
        if(state == 0)
        {
            write(fd,"1",1);
        }
    }
    ::close(fd);

}

void Widget::lora_set(int mode)
{
    int fd_m0, fd_m1;
    fd_m0 = open(M0_GPIO_VALUE,O_WRONLY);
    fd_m1 = open(M1_GPIO_VALUE,O_WRONLY);
    qDebug() << fd_m0 << fd_m1;
    if(mode == NOR)
    {
        write(fd_m0,"0",1);
        write(fd_m1,"0",1);

    }else if(mode == WOR){

        write(fd_m0,"1",1);
        write(fd_m1,"0",1);
    }else if(mode == CFG){

        write(fd_m0,"0",1);
        write(fd_m1,"1",1);
    }else{
        write(fd_m0,"1",1);
        write(fd_m1,"1",1);
    }
    ::close(fd_m0);
    ::close(fd_m1);
}

//每秒种更新时间显示，也读取一次数据
void Widget::acq_timeout(void)
{
    QDateTime dateTime= QDateTime::currentDateTime();//获取系统当前的时间
    QString ntime = dateTime .toString("yyyy-MM-dd-hh:mm:ss");//格式化时间

    if(received == true)
    {
        //qDebug() << "received";
        //
        QString temp = ntime + "--" + QString::number(index) + " " +QString::number(val_humi) + " "+ QString::number(val_temp) + " "+ QString::number(val_light)
                       + " "+ QString::number(val_press) + " "+ QString::number(val_co2) + " "+ QString::number(val_bat) + " "+ QString::number(val_yw) + "\n"; // 写入内容

        QTextStream out(file);
        out << temp;
        file->flush();

    }else{
        //qDebug() << "not recv";
        QString temp = ntime + "--node " + QString::number(index) +" is offline\n"; // 写入内容
        QTextStream out(file);
        out << temp;
        file->flush();
    }
    index += 1;
    if(index > 4) index = 1;
    emit sgl_acq(index); //continue to acq next
}



void Widget::data_acq(uint8_t index)
{
    QString id = QString("%1").arg(index,2,16,QLatin1Char('0'));
    QString cmd = "00 " + id + " 16 ff cc 00 00 00 ff";
    qDebug() << cmd;
    serial_write(hex_str_to_ba(cmd));
    received = false;
    time_acp->setInterval(600); //time for timeout
    time_acp->start();
}

void Widget::serial_refresh(){

     QList<QSerialPortInfo> serial_list;

     serial_list = QSerialPortInfo::availablePorts();

     for(int i=0;i<serial_list.size();i++){
          //ui->comboBox_com->addItem(serial_list.at(i).portName());// + " " + serial_list.at(i).description());
          qDebug() << serial_list.at(i).portName() + serial_list.at(i).description();
     }

}

void Widget::serial_init(){

    serial = new QSerialPort();
    serial_timer = new QTimer();

    connect(serial, SIGNAL(readyRead()), this, SLOT(serial_read_timeout()));
    connect(serial_timer, SIGNAL(timeout()), this, SLOT(serial_read()));


    serial->setPortName("/dev/ttyS1");
    serial->setBaudRate(9600);

    if(serial->open(QIODevice::ReadWrite)){

        serial->waitForReadyRead(10);

    }
    qDebug() << "ttyS0 opened";
}

//QByteArray转16进制字符串
QString Widget::ba_to_hex_str(QByteArray ba){

    QString str,tmp;

    tmp.append(ba.toHex().toUpper());

    for(int i=0;i<ba.count();i++) {
        str.append(tmp.mid(i*2,2)+" ");
    }

    str.chop(1);

    return str;
}

//16进制字符串转QByteArray
QByteArray Widget::hex_str_to_ba(QString str){

    bool ok;
    QByteArray ba;
    QStringList str_list;
    str_list = str.split(" ");

    for(int i=0;i<str_list.size();i++){
        ba.append(str_list.at(i).toUInt(&ok,16));
    }

    //ba.append()
    return ba;
}

//串口超时
void Widget::serial_read_timeout()
{
    serial_timer->start(50);
}


//串口发送数据
void Widget::serial_write(QByteArray ba)
{

    serial->write(ba);
    qDebug()<<"send data:"<<ba_to_hex_str(ba);
    serial->waitForBytesWritten(200);

}


//串口接收数据
void Widget::serial_read(){

    QByteArray ba;
    quint8 recv[32];
    quint16 len;
    quint16 temp;
    ba = serial->readAll();
    len = ba.size(); //data length
    memcpy(recv,ba,len);

     //get the sensor value
    if(recv[0] == 0xff && recv[19] == 0xff)
    {
        received = true;
        //qDebug() << ba_to_hex_str(ba) << recv[0];
        val_humi = recv[3] + recv[4] * 0.1;
        val_temp = recv[5] + recv[6] * 0.1;
        val_light = (recv[7] << 8) | recv[8];
        val_press = (recv[9] << 24) |  (recv[10] << 16) | (recv[11] << 8) | recv[12];
        val_co2 = (recv[13] << 8) | recv[14];
        val_bat = (recv[15] << 8) | recv[16];
        val_yw = (recv[17] << 8) | recv[18];
        qDebug() << val_humi << val_temp <<  val_light << val_press<<val_co2<<val_bat<<val_yw;

        if(val_humi<humi_min||val_humi>humi_max)
        {
            if(!humi_warning)
            {
//                send_emil();
                humi_warning=true;
            }
        }
        else
        {
            humi_warning=false;
        }



        //程序打印的数据就是这里的几个变量，node[4][7]四个节点的7个值，当前读到的值是node[index]  电量 val_bat/1000/（4.2-3）* 100 就是百分比
    }else{
        ;
    }

    ba.clear();

    serial_timer->stop();
}



